-- "addons\\homigrad\\lua\\hlocalize\\en\\scoreboard\\_pages_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.game = "Game"
l.graphics = "Graphics"
l.sound = "Sound"
l.interface = "Interface"
