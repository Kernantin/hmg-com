-- "addons\\homigrad\\lua\\hlocalize\\en\\scoreboard\\scoreboard_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.settings = "Settings"
l.class = "Class"
l.inventory = "Inventory"
l.scoreboard = "Players"

l.scoreboard_players = "Players: %s"

l.scoreboard_status = "Status"
l.scoreboard_team = "Team"
l.scoreboard_name = "Name"
l.scoreboard_ping = "Ping"
l.scoreboard_played = "Played"

l.live = "Live"
l.dead = "Dead"
l.scoreboard_live = "Live"
l.scoreboard_dead = "Dead"
l.scoreboard_spectate = "Spectate"
l.scoreboard_unknown = "Unknown"

l.scoreboard_muteall = "Mute all"
l.scoreboard_mutedead = "Mute dead"
l.scoreboard_tickrate = "Tickrate: %s"

l.open_profile = "Open profile"
l.copy_steamid = "Copy SteamID"
l.steamid_coped = "%s(%s) coped!"