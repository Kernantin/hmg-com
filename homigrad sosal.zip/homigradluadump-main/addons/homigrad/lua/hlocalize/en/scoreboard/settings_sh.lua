-- "addons\\homigrad\\lua\\hlocalize\\en\\scoreboard\\settings_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.settings_camera = "Camera"
l.settings_playsound_startround = "Play the sound of the start of a round"

l.settings_main = "Main"

l.interface_multiply_screen = "Screen size multiplier"
l.interface_multiply_screen2 = "Resizes the interface, font, buttons."

l.settings_dwr = "Enable weapon/explosion reverb"
l.settings_dwr_volume = "Reverb volume"
l.settings_volume_shootgun = "Weapon volume"