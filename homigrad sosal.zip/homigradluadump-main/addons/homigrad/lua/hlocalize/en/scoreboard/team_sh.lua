-- "addons\\homigrad\\lua\\hlocalize\\en\\scoreboard\\team_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.team = "Teams"
l.select_team = "Select your team"
l.spectator = "Spectator"
l.spectators = "Spectators"

l.you_select_team = "Yout stand up for %s"