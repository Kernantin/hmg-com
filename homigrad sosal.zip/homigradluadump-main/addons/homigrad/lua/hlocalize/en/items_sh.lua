-- "addons\\homigrad\\lua\\hlocalize\\en\\items_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.weapon_author = "Author"
l.weapon_instruction = "Instruction"

l.weapon_medkit = "Medkit"
l.weapon_medkit_desc = "Has bandages and painkillers"