-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\bhop_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.bhop = "Bhop"
l.bhop_loadscreen = "Kill them all, they don't deserve any better."
l.bhop_loadscreen2 = "ALT to see who's hiding."

l.deadrun_die_in_ragdoll = "You have %s seconds left until you die"
l.deadrun_bhop = "%s of jumps in reserve"