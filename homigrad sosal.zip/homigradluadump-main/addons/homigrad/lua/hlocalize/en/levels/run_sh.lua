-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\run_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.run = "Potato"
l.run_loadscreen_withgun = "With gun"
l.run_loadscreen1 = "You have to pass the potato so it doesn't explode."
l.run_loadscreen2 = "ALT to see who's hiding.."
