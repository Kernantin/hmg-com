-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\construct_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.spawnpoint_free = "Free"
l.spawnpoint_set = "Spawnpoint set"

l.cupboard = "Cupboard"
l.cupboard_set = "Cupboard activated"

l.click_for_spawn = "Click on PCM or LKM to revive"
l.spawn_from_second = "Remaining : %s seconds"

l.construct_timetokill1 = "TIME TO KILL!!!11"
l.construct_timetokill2 = "Respawn impossible, kill everyone to end mode"