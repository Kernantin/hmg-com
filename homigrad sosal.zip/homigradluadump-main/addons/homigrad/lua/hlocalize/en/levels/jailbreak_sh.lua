-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\jailbreak_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.jailbreak = "Jail Break"
l.jailbreak_minonect = "The game can't start until there's at least one guard."
l.jailbreak_minonet = "The game can't start until there's at least one convict."
l.jailbreak_openclose = "Open/Close"
l.jailbreak_randomjoin = "Join Random CT"

l.jailbreak_red = "Gangshit"
l.jailbreak_blue = "Trash bucket"

l.jailbreak_rank_1 = "Scout"
l.jailbreak_rank_2 = "Sarge"
l.jailbreak_rank_3 = "Major"
l.jailbreak_rank_4 = "General RF"