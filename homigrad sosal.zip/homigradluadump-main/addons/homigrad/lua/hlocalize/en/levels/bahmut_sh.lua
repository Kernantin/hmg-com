-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\bahmut_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.bahmut = "UMF vs MFRF"
l.bahmut_loadscreen = "Neutralize the enemy team, abide by military rules, rescue your own."
l.bahmut_red = "MFRF"
l.bahmut_blue = "UMF"