-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\deadrun_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.deathrun = "DeathRun"