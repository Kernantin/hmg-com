-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\tdm_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.tdm = "Team Dead Match"
l.tdm_loadscreen = "Neutralize the enemy team ..."
l.tdm_win = "Winners - %s"
l.tdm_win_nobody = "Win friendship."

l.terrorist = "Terrorist"
l.contr_terrorist = "Contr-Terrorist"