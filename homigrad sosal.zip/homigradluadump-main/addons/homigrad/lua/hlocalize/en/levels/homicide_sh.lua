-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\homicide_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.homicide = "Homicide"
l.innocent = "Innocent"
l.traitor = "Traitor"

l.homicide_loadscreen = "Find the traitor, tie him up or kill him for victory. Trust no one..."

l.homicide_loadscreen_roleT = "Your job is to kill everyone before the police arrive"
l.homicide_loadscreen_roleCT = "You have a concealed firearm, try to neutralize the traitor"
l.homicide_loadscreen_roleCT2 = "You have a large-sized weapon, try to neutralize the traitor"

l.homicide_win_t = "The victory of the traitors."
l.homicide_win_ct = "Victory of the innocent."
l.homicide_traitor_was = "The traitors were: %s"
l.homicide_traitor_wasone = "The traitor was: %s"
 
l.tbut_single = "Single"
l.tbut_reuse = "Reuse"
l.tbut_retime = "Ready %s"