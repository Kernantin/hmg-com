-- "addons\\homigrad\\lua\\hlocalize\\en\\levels\\riot_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.en

l.riot = "RIOT"
l.riot_loadscreen_team2 = "Neutralize the rioting people, try not to kill them"
l.riot_loadscreen_team1 = "Preserve your rights! Destroy all those who would torment you!"
l.riot_rebels = "Rebels"
l.police = "Police"