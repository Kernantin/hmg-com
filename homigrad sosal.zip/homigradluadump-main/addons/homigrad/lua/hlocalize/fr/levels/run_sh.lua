-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\run_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.run = "Patate"
l.run_loadscreen_withgun = "Avec le pistolet"
l.run_loadscreen1 = "Vous devez passer la patate pour qu'elle n'explose pas (la toucher)"
l.run_loadscreen2 = "ALT pour voir l'homme qui se cache"