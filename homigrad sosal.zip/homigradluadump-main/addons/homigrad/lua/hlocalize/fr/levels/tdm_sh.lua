-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\tdm_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.tdm = "Match mortel par équipe"
l.tdm_loadscreen = "Neutralisez l'équipe ennemie..."
l.tdm_win = "Victoire - %s"
l.tdm_win_nobody = "Amitié"

l.terrorist = "Terroriste"
l.contr_terrorist = "Contr-Terroriste"
