-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\construct_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.spawnpoint_free = "Libre"
l.spawnpoint_set = "Jeu de points d'ancrage"

l.cupboard = "Armoire"
l.cupboard_set = "Armoire activée"

l.click_for_spawn = "Press PCM or LKM to spawn"
l.spawn_from_second = "Remaining : %s seconds"

l.construct_timetokill1 = "TIME TO KILL!!11"
l.construct_timetokill2 = "Pas de respawn possible, tuez tout le monde pour terminer le mode"