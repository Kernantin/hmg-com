-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\bahmut_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.bahmut = "AFU vs VSRF"
l.bahmut_loadscreen = "Neutralisez l'équipe ennemie, suivez les règles militaires, sauvez les vôtres."
l.bahmut_red = "VSRF"
l.bahmut_blue = "AFU"
