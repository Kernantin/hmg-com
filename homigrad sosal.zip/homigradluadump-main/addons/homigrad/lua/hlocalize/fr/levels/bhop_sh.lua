-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\bhop_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.bhop = "Bhop"
l.bhop_loadscreen = "Tuez-les tous, ils ne méritent pas mieux."
l.bhop_loadscreen2 = "ALT pour voir qui se cache."

l.deadrun_die_in_ragdoll = "Il vous reste %s secondes pour mourir."
l.deadrun_bhop = "%s jumps to spare."
