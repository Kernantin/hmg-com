-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\jailbreak_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.jailbreak = "Jail Break"
l.jailbreak_minonect = "Le jeu ne peut pas commencer tant qu'il n'y a pas au moins un garde."
l.jailbreak_minonet = "Le jeu ne peut pas commencer tant qu'il n'y a pas au moins un condamné."
l.jailbreak_openclose = "Fermer/Ouvrir"
l.jailbreak_randomjoin = "Rejoindre un CT aléatoire"

l.jailbreak_red = "Cons"
l.jailbreak_blue = "Corbeille"

l.jailbreak_rank_1 = "Privé"
l.jailbreak_rank_2 = "Sergent"
l.jailbreak_rank_3 = "Major"
l.jailbreak_rank_4 = "Général de la Fédération de Russie"
