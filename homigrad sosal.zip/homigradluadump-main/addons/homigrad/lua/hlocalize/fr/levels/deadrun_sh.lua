-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\deadrun_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.deathrun = "DeathRun"