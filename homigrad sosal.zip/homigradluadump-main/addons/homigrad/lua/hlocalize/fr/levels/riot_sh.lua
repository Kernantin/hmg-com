-- "addons\\homigrad\\lua\\hlocalize\\fr\\levels\\riot_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.riot = "RIOT"
l.riot_loadscreen_team2 = "Neutralisez les émeutiers, essayez de ne pas tuer"
l.riot_loadscreen_team1 = "Gardez vos droits ! Détruisez tous ceux qui veulent vous tourmenter !"
l.riot_rebels = "Rebelles"
l.police = "Police"