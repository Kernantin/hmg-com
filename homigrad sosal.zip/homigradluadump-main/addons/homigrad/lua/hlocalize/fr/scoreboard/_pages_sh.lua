-- "addons\\homigrad\\lua\\hlocalize\\fr\\scoreboard\\_pages_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.game = "Jeu"
l.graphics = "Graphique"
l.sound = "Son"
l.interface = "Interface"
