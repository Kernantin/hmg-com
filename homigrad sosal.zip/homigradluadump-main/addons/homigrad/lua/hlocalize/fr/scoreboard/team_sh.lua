-- "addons\\homigrad\\lua\\hlocalize\\fr\\scoreboard\\team_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.team = "Équipe"
l.select_team = "Sélectionner l'équipe"
l.spectator = "Observateur"
l.spectators = "Spectateurs"

l.you_select_team = "Vous représentez %s"
