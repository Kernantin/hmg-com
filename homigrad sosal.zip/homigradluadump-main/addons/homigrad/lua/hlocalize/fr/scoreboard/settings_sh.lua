-- "addons\\homigrad\\lua\\hlocalize\\fr\\scoreboard\\settings_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.settings_camera = "Appareil photo"
l.settings_playsound_startround = "Jouer le son startround"

l.settings_main = "Principal"

l.interface_multiply_screen = "Multiplicateur de taille d'écran"
l.interface_multiply_screen2 = "Redimensionne l'interface, la police, les boutons."

l.settings_dwr = "Activer la réverbération des armes/explosions"
l.settings_dwr_volume = "Volume de la réverbération"
l.settings_volume_shootgun = "Volume de l'arme"
