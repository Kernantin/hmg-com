-- "addons\\homigrad\\lua\\hlocalize\\fr\\scoreboard\\scoreboard_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.fr

l.settings = "Paramètres"
l.class = "Classes"
l.inventory = "Inventaire"
l.scoreboard = "Joueurs"

l.scoreboard_players = "Joueurs : %s"

l.scoreboard_status = "Statut"
l.scoreboard_team = "Équipe"
l.scoreboard_name = "Nom"
l.scoreboard_ping = "Ping"
l.scoreboard_played = "Joué"

l.live = "Live"
l.dead = "Mort"
l.scoreboard_live = "Vivant"
l.scoreboard_dead = "Mort"
l.scoreboard_spectate = "Observer"
l.scoreboard_untiled = "Inconnu"

l.scoreboard_muteall = "Tout mettre en sourdine"
l.scoreboard_mutedead = "Couper les morts"
l.scoreboard_tickrate = "Tickrate : %s"

l.open_profile = "Ouvrir le profil"
l.copy_steamid = "Copier l'identifiant Steam"
l.steamid_coped = "%s(%s) copied !"
