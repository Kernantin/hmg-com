-- "addons\\homigrad\\lua\\hlocalize\\ru\\items_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.weapon_author = "Автор"
l.weapon_instruction = "Инструкция"

l.weapon_medkit = "Аптечка"
l.weapon_medkit_desc = "Имеет в себе бинты и обезболивающие"