-- "addons\\homigrad\\lua\\hlocalize\\ru\\scoreboard\\_pages_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.game = "Игра"
l.graphics = "Графика"
l.sound = "Звуки"
l.interface = "Интерфейс"
