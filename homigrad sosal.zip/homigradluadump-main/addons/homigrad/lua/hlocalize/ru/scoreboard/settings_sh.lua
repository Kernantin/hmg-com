-- "addons\\homigrad\\lua\\hlocalize\\ru\\scoreboard\\settings_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.settings_camera = "Камера"
l.settings_playsound_startround = "Воспроизводить звук начала раунда"

l.settings_main = "Главное"

l.interface_multiply_screen = "Множитель размера экрана"
l.interface_multiply_screen2 = "Изменяет размер интерфейса, шрифта, кнопок."

l.settings_dwr = "Включить ревербирацию оружия/взрывов"
l.settings_dwr_volume = "Громкость ревербирации"
l.settings_volume_shootgun = "Громкость оружия"