-- "addons\\homigrad\\lua\\hlocalize\\ru\\scoreboard\\scoreboard_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.settings = "Настройки"
l.class = "Классы"
l.inventory = "Инвентарь"
l.scoreboard = "Игроки"

l.scoreboard_players = "Игроков: %s"

l.scoreboard_status = "Статус"
l.scoreboard_team = "Команда"
l.scoreboard_name = "Имя"
l.scoreboard_ping = "Пинг"
l.scoreboard_played = "Наигранно"

l.live = "Живой"
l.dead = "Мёртв"
l.scoreboard_live = "Живой"
l.scoreboard_dead = "Мёртв"
l.scoreboard_spectate = "Наблюдает"
l.scorebaord_untiled = "Неизвестно"

l.scoreboard_muteall = "Замутить всех"
l.scoreboard_mutedead = "Замутить мёртвых"
l.scoreboard_tickrate = "Тикрейт: %s"

l.open_profile = "Открыть профиль"
l.copy_steamid = "Скопировать SteamID"
l.steamid_coped = "%s(%s) скопирован!"
