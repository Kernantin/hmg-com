-- "addons\\homigrad\\lua\\hlocalize\\ru\\scoreboard\\class_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.team = "Команда"
l.select_team = "Выберете команду"
l.spectator = "Наблюдатель"
l.spectators = "Наблюдатели"

l.you_select_team = "Ты встал за %s"

l.class_solder = "Солдат"
l.class_scout = "Разведчик"
l.class_support = "Поддержка"
l.class_sniper = "Снайпер"