-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\run_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.run = "Картошка"
l.run_loadscreen_withgun = "С оружием"
l.run_loadscreen1 = "Вы должны передать картошку, что-бы не взорватся (ударь его)"
l.run_loadscreen2 = "ALT что-бы увидеть прячущегося."
