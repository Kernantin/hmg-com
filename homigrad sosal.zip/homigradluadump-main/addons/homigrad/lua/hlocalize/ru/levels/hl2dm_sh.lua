-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\hl2dm_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.hl2dm = "HL2DM"
l.hl2dm_loadscreen = "Нейтрализуйте вражескую команду, спасайте своих..."
l.hl2dm_rebels = "Повстанцы"
l.combine = "Комбайны"