-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\tdm_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.tdm = "Team Dead Match"
l.tdm_loadscreen = "Нейтрализуйте вражескую команду..."
l.tdm_win = "Выиграли - %s"
l.tdm_win_nobody = "Дружба."

l.terrorist = "Terrorist"
l.contr_terrorist = "Contr-Terrorist"