-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\construct_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.spawnpoint_free = "Свободно"
l.spawnpoint_set = "Точка возрождения поставлена."

l.cupboard = "Шкаф"
l.cupboard_set = "Шкаф активирован."

l.click_for_spawn = "Нажми на ПКМ или ЛКМ что-бы возродится."
l.spawn_from_second = "Осталось : %s секунд."

l.construct_timetokill1 = "ВРЕМЯ УБИВАТЬ!!11"
l.construct_timetokill2 = "Респавн невозможен, убейте всех что-бы закончить режим."