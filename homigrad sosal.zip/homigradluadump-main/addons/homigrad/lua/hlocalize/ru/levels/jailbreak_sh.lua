-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\jailbreak_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.jailbreak = "Jail Break"
l.jailbreak_minonect = "Игра не может начаться пока не будет хотябы один охраник."
l.jailbreak_minonet = "Игра не может начаться пока не будет хотябы один зек."
l.jailbreak_openclose = "Закрыть/Открыть"
l.jailbreak_randomjoin = "Join Random CT"

l.jailbreak_red = "Зеки"
l.jailbreak_blue = "Мусора"

l.jailbreak_rank_1 = "Рядовой"
l.jailbreak_rank_2 = "Сержант"
l.jailbreak_rank_3 = "Майор"
l.jailbreak_rank_4 = "Генерал РФ"