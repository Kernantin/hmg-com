-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\homicide_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.homicide = "Homicide"
l.innocent = "Невиновный"
l.traitor = "Предатель"

l.homicide_loadscreen = "Найдите предателя, свяжите или убейте его для победы. Не доверяйте никому..."

l.homicide_loadscreen_roleT = "Ваша задача убить всех до прибытия полиции"
l.homicide_loadscreen_roleCT = "У вас есть скрытое огнестрельное оружие, постарайтесь нейтрализовать предателя"
l.homicide_loadscreen_roleCT2 = "У вас есть крупногабаритное оружие, постарайтесь нейтрализовать предателя"

l.homicide_win_t = "Победа предателей."
l.homicide_win_ct = "Победа невиновых."
l.homicide_traitor_was = "Предателями были: %s"
l.homicide_traitor_wasone = "Предателем был: %s"

l.tbut_single = "Один раз"
l.tbut_reuse = "Откат"
l.tbut_retime = "Готов %s"