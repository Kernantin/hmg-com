-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\bahmut_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.bahmut = "ВСУ vs ВСРФ"
l.bahmut_loadscreen = "Нейтрализуйте вражескую команду, соблюдайте военные правила, спасайте своих."
l.bahmut_red = "ВСРФ"
l.bahmut_blue = "ВСУ"