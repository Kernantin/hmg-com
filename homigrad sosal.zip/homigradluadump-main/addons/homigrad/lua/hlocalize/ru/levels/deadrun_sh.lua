-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\deadrun_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.deathrun = "DeathRun"