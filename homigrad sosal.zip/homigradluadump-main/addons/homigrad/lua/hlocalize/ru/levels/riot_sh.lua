-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\riot_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.riot = "RIOT"
l.riot_loadscreen_team2 = "Нейтрализуйте бунтующих людей, старайтесь не убивать"
l.riot_loadscreen_team1 = "Сохраните свои права! Уничтожте всех тех, кто вас будет торомзить!"
l.riot_rebels = "Бунтующие"
l.police = "Полиция"
