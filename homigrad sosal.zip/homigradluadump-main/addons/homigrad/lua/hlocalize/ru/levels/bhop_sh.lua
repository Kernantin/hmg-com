-- "addons\\homigrad\\lua\\hlocalize\\ru\\levels\\bhop_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local l = LOCALIZE.ru

l.bhop = "Bhop"
l.bhop_loadscreen = "Убей их всех, они не заслужили большего."
l.bhop_loadscreen2 = "ALT что-бы увидеть прячущегося."

l.deadrun_die_in_ragdoll = "У тебя осталось %s секунд до смерти"
l.deadrun_bhop = "%s прыжков в запасе"
