-- "addons\\homigrad\\lua\\hgame\\tier_1\\movement_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
hook.Add("SetupMove","Jump Delay",function(ply,mv)

end)