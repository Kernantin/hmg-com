-- "addons\\homigrad\\lua\\hgame\\tier_1\\damage\\reasons_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
//