-- "addons\\drug\\lua\\entities\\durgz_water\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "durgz_base"
ENT.PrintName = "Water"
ENT.Category = "Drugs"
ENT.Nicknames = {0}
ENT.OverdosePhrase = {0}
ENT.Author = "Jesus Christ"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Information	 = "Clears the mind" 
ENT.WorldModel = "models/drug_mod/the_bottle_of_water.mdl"
