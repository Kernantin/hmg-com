-- "addons\\dwr\\lua\\autorun\\client\\dwr_client.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
//in homigrad