-- "addons\\homigrad_core\\lua\\shlib\\tier_0\\tier_0\\player\\msg_sh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
COLOR_SERVER_MESSAGE = Color( 156, 241, 255, 200 )
COLOR_SERVER_ERROR = Color( 156, 241, 255, 200 )

COLOR_CLIENT_MESSAGE = Color( 255, 241, 122, 200 )
COLOR_CLIENT_ERROR = Color( 255, 221, 102, 255 )

COLOR_MENU_MESSAGE = Color( 100, 220, 100, 200 )
COLOR_MENU_ERROR = Color( 120, 220, 100, 255 )