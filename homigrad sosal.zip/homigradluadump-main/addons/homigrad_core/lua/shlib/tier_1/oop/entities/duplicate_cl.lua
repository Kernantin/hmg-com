-- "addons\\homigrad_core\\lua\\shlib\\tier_1\\oop\\entities\\duplicate_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local LIB = oop.Reg("lib_duplicate")
if not LIB then return end

//а хуй тэбэ