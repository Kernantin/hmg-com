-- "addons\\homigrad_core\\lua\\shlib\\tier_1\\oop\\vgui\\content\\mark_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = oop.Reg("v_mark","v_panel")
if not PANEL then return end

