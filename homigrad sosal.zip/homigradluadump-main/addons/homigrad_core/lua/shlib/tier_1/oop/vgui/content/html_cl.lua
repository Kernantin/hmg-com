-- "addons\\homigrad_core\\lua\\shlib\\tier_1\\oop\\vgui\\content\\html_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = oop.Reg("v_html","v_panel")
if not PANEL then return end

PANEL.Base = "DHTML"