-- "addons\\homigrad_core\\lua\\shlib\\tier_1\\oop\\vgui\\content\\frame_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = oop.Reg("v_frame","v_panel")
if not PANEL then return end

PANEL.Base = "EditablePanel"