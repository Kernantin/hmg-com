-- "addons\\homigrad_core\\lua\\shlib\\tier_1\\playerclass\\connect\\hook_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
//noy