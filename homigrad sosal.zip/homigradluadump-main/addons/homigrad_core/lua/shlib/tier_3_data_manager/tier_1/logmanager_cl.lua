-- "addons\\homigrad_core\\lua\\shlib\\tier_3_data_manager\\tier_1\\logmanager_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
function SendLog(data) event.Call("Log",data) end
