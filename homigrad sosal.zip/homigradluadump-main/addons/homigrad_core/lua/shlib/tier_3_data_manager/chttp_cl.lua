-- "addons\\homigrad_core\\lua\\shlib\\tier_3_data_manager\\chttp_cl.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
require("chttp")

if CHTTP then HTTP = CHTTP end